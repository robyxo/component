﻿import { useState } from 'react';
import { Button } from './Style/ComponentStyle'

function ButtonSymbol({ifSymbol}) {
    const [symbol, setSymbol] = useState('▼');
    const changeSymbol = () => {
        setSymbol(symbol === '▼' ? '▲' : '▼');
        ifSymbol();
    };

  return (
      <Button onClick={changeSymbol}>
          {symbol}
      </Button>
  );
}

export default ButtonSymbol;