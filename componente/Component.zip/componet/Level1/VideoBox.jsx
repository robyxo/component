import { BoxVideo, PlayButton, DeleteIconBox, Title, ProgressBar, ScrollButtons, ScrollButton, DeleteIcon, OscureContent, OscureContainer } from './Style/styledVideoBox'

function VideoBox() {
    return (
        <>
            <OscureContainer>
          <BoxVideo>
              <PlayButton>&#9654;</PlayButton>
              <DeleteIconBox>&#128465;</DeleteIconBox>
              <Title>This is a sample video title that gets truncated when it reaches the border.</Title>
              <ProgressBar style={{ width: '50%' }} />
            </BoxVideo>
                <OscureContent>
                    <ScrollButtons>
                        <ScrollButton>&#9650;</ScrollButton>
                        <ScrollButton>&#9660;</ScrollButton>
                    </ScrollButtons>
                    <DeleteIcon>&#128465;</DeleteIcon>
                </OscureContent>
            </OscureContainer>
      </>

  );
};

export default VideoBox;