import styled from 'styled-components';

const BoxVideo = styled.div`
  width: 162px;
  height: 41px;
  border: 1px solid rgba(23, 23, 23, 0.24);
  margin-right: 106px;
  overflow: hidden;
  position: relative;
  border-radius: 5px;
`;

const PlayButton = styled.button`
  position: absolute;
  top: 35%;
  transform: translateY(-50%);
  background-color: transparent;
  border: none;
  cursor: pointer;
  font-size: 12px;
  color: #575757;
`;

const DeleteIconBox = styled.span`
  position: absolute;
  top: 28%;
  right: 5px;
  transform: translateY(-50%);
  font-size: 13px;
  color: #575757;
  cursor: pointer;
`;

const ProgressBar = styled.div`
  position: absolute;
  bottom: 6px;
  left: 0;
  height: 3px;
  background-color: #e67e22;
`;
const Title = styled.div`
  position: absolute;
  top: 33%;
  left: 52%;
  transform: translate(-50%, -50%);
  font-size: 10px;
  color: #575757;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 115px;
  height: 12px;
`;
const ScrollButtons = styled.div`
  position: absolute;
  top: 52%;
  right: 66px;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const ScrollButton = styled.button`
  background-color: transparent;
  border: none;
  cursor: pointer;
  font-size: 15px;
  color: #575757;
  margin-bottom: -2px;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #f0f0f0;
    border-radius: 150%;
  }
`;

const DeleteIcon = styled.span`
    position: absolute;
    top: 52%;
    right: 32px;
    transform: translateY(-50%);
    font-size: 30px;
    color: black;
    cursor: pointer;
`;


const OscureContainer = styled.div`
  position: relative;
`;

const OscureContent = styled.div`
  opacity: 0; 
  transition: opacity 0.3s ease;

  ${OscureContainer}:hover & {
    opacity: 1; 
  }
`;
export { BoxVideo, PlayButton, DeleteIconBox, Title, ProgressBar, ScrollButtons, ScrollButton, DeleteIcon, OscureContent, OscureContainer };